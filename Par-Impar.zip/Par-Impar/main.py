from random import randint
s = c = 0
while True:
    m = randint(0, 10)
    o = str(input ('Você prefere par ou ímpar? ')). strip().lower()[0]
    j = int(input ('Diga o seu número: '))
    s = m + j
    print ('=-=' * 14)
    if o == 'p':
        if s % 2 == 0:
            c += 1
            print ('A soma entre {} e {} é de {}, um valor PAR.'.format (j, m, s))
            print ('Você venceu! Vamos de novo...')
        else:
            print ('A soma entre {} e {} é de {}, um valor ÍMPAR'.format(j, m, s))
            break
    elif o == 'i' or o == 'í':
        if s % 2 != 0:
            c += 1
            print ('A soma entre {} e {} é de {}, um valor ÍMPAR'.format(j, m, s))
            print ('Você venceu! Vamos de novo...')
        else:
            print ('A soma entre {} e {} é de {}, um valor PAR.'.format(j, m, s))
            break
    else:
        print ('Opção inválida. Tente novamente.')
    print('=-=' * 14)
print ('Você perdeu. \nCom uma série de {} vitorias consecutivas.'.format(c))
print ('Volte sempre =)')